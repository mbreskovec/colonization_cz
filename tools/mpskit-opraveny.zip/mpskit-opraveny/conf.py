from record import Record

conf = Record()
